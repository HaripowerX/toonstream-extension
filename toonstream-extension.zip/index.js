const baseUrl = "https://toonstream.dad";

// 🔥 Helper: fetch + parse HTML
async function fetchDoc(url) {
    const res = await fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0"
        }
    });
    const html = await res.text();
    return new DOMParser().parseFromString(html, "text/html");
}

// 🔍 1. Get Anime List
async function getAnimeList(page = 1) {
    const doc = await fetchDoc(`${baseUrl}/anime?page=${page}`);

    const items = [...doc.querySelectorAll(".film_list-wrap .flw-item")];

    return items.map(el => ({
        title: el.querySelector(".film-name")?.innerText.trim(),
        url: baseUrl + el.querySelector("a")?.getAttribute("href"),
        image: el.querySelector("img")?.getAttribute("data-src") || el.querySelector("img")?.src
    }));
}

// 📖 2. Anime Details
async function getAnimeDetails(url) {
    const doc = await fetchDoc(url);

    return {
        title: doc.querySelector(".film-name")?.innerText.trim(),
        image: doc.querySelector(".film-poster img")?.src,
        description: doc.querySelector(".film-description")?.innerText.trim()
    };
}

// 📺 3. Episodes
async function getEpisodes(url) {
    const doc = await fetchDoc(url);

    const eps = [...doc.querySelectorAll(".ep-item")];

    return eps.map(ep => ({
        title: "Episode " + ep.getAttribute("data-number"),
        url: baseUrl + ep.getAttribute("href")
    })).reverse(); // oldest first
}

// ▶️ 4. Video extraction
async function getVideo(episodeUrl) {
    const doc = await fetchDoc(episodeUrl);

    // Step 1: find iframe
    const iframe = doc.querySelector("iframe");

    if (!iframe) {
        throw new Error("No video iframe found");
    }

    const iframeUrl = iframe.src.startsWith("http")
        ? iframe.src
        : baseUrl + iframe.src;

    // Step 2: fetch iframe page
    const iframeRes = await fetch(iframeUrl, {
        headers: {
            "Referer": episodeUrl
        }
    });

    const iframeHtml = await iframeRes.text();

    // Step 3: find m3u8 link
    const m3u8Match = iframeHtml.match(/https?:\/\/.*?\.m3u8/);

    if (m3u8Match) {
        return {
            url: m3u8Match[0],
            type: "hls"
        };
    }

    // fallback mp4
    const mp4Match = iframeHtml.match(/https?:\/\/.*?\.mp4/);

    if (mp4Match) {
        return {
            url: mp4Match[0],
            type: "mp4"
        };
    }

    throw new Error("Video not found");
}

// 🔎 5. Search
async function search(query) {
    const doc = await fetchDoc(`${baseUrl}/search?keyword=${encodeURIComponent(query)}`);

    const items = [...doc.querySelectorAll(".film_list-wrap .flw-item")];

    return items.map(el => ({
        title: el.querySelector(".film-name")?.innerText.trim(),
        url: baseUrl + el.querySelector("a")?.getAttribute("href"),
        image: el.querySelector("img")?.getAttribute("data-src") || el.querySelector("img")?.src
    }));
}

// 📦 Export (important)
module.exports = {
    getAnimeList,
    getAnimeDetails,
    getEpisodes,
    getVideo,
    search
};